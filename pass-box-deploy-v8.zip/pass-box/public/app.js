let csrfToken = '';
let currentUser = null;
let pendingEmail = '';

const page = document.body.dataset.page;
const nextTarget = (() => {
  const value = new URLSearchParams(window.location.search).get('next');
  return value && value.startsWith('/') && !value.startsWith('//') ? value : '';
})();

const api = async (url, options = {}) => {
  const headers = { Accept: 'application/json', ...(options.headers || {}) };
  if (options.body && typeof options.body !== 'string') {
    headers['Content-Type'] = 'application/json';
    options = { ...options, body: JSON.stringify(options.body) };
  }
  if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
  const response = await fetch(url, { ...options, headers, credentials: 'include' });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(result.error || '请求失败，请稍后再试。');
    error.status = response.status;
    error.code = result.code;
    throw error;
  }
  return result;
};

const setStatus = (element, message, success = false) => {
  if (!element) return;
  element.textContent = message;
  element.classList.toggle('success', success);
};

const redirectAfterAuth = () => {
  window.location.href = nextTarget || '/compare.html';
};

const updateAuthLink = () => {
  document.querySelectorAll('.auth-link').forEach((link) => {
    if (currentUser) {
      link.textContent = `已登录 · ${currentUser.email}`;
      link.href = page === 'account' ? '#account' : '/';
    } else {
      link.textContent = '登录 / 注册';
      link.href = page === 'account' ? '#account' : `/?next=${encodeURIComponent(window.location.pathname)}`;
    }
  });
};

const restoreSession = async () => {
  try {
    const session = await api('/api/auth/session');
    if (session.authenticated) {
      currentUser = session.user;
      csrfToken = session.csrfToken;
    }
  } catch {
    currentUser = null;
  }
  updateAuthLink();
  return currentUser;
};

const loadConfig = async () => api('/api/config');

const formatClaimLabel = (claim) => {
  if (claim.open) return '资格申请开放中';
  if (claim.openAt) {
    const formatted = new Intl.DateTimeFormat('zh-CN', {
      timeZone: 'Asia/Shanghai',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(claim.openAt));
    return `资格登记将于北京时间 ${formatted} 开放`;
  }
  return claim.label;
};

const formatShippingDate = (date) => {
  if (!date) return '发货时间待定';
  return `${new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric' }).format(new Date(`${date}T00:00:00+08:00`))} 发货`;
};

const formatProductState = (product, claim) => {
  const shipping = formatShippingDate(product.shippingDate);
  if (product.remaining <= 0) return `已售罄 · 剩余 0 个 · ${shipping}`;
  if (!claim.open) return `${formatClaimLabel(claim)} · 剩余 ${product.remaining}/${product.limit} · ${shipping}`;
  return `开放中 · 剩余 ${product.remaining}/${product.limit} · ${shipping}`;
};

const pollConfig = (applyConfig) => {
  window.setInterval(async () => {
    try {
      applyConfig(await loadConfig());
    } catch {
      // Keep the last known state during a transient network failure.
    }
  }, 15000);
};

const setupAccountPage = async () => {
  const card = document.querySelector('.account-card');
  const tabs = document.querySelectorAll('.tab');
  const form = document.querySelector('#account-form');
  const verifyPanel = document.querySelector('#verify-panel');
  const verifyForm = document.querySelector('#verify-form');
  const emailInput = document.querySelector('#email');
  const passwordInput = document.querySelector('#password');
  const confirmInput = document.querySelector('#confirm');
  const consent = document.querySelector('#consent');
  const accountStatus = document.querySelector('#account-status');
  const verifyStatus = document.querySelector('#verify-status');
  const pendingEmailText = document.querySelector('#pending-email');
  const resendButton = document.querySelector('#resend-code');
  const successPanel = document.querySelector('#success-panel');
  const redirectNow = document.querySelector('#redirect-now');
  const claimLabel = document.querySelector('#claim-status-label');

  const applyConfig = (config) => {
    if (claimLabel) claimLabel.textContent = formatClaimLabel(config.claim);
  };

  try {
    applyConfig(await loadConfig());
    pollConfig(applyConfig);
  } catch {
    setStatus(accountStatus, '服务器暂时无法读取开放状态。');
  }

  tabs.forEach((tab) => tab.addEventListener('click', () => {
    const login = tab.dataset.mode === 'login';
    tabs.forEach((item) => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    card.classList.toggle('login-mode', login);
    setStatus(accountStatus, '');
  }));

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    setStatus(accountStatus, '正在处理……');
    const login = card.classList.contains('login-mode');
    const email = emailInput.value.trim();
    if (!email || !email.includes('@')) { setStatus(accountStatus, '请输入有效邮箱。'); return; }
    if (passwordInput.value.length < 8) { setStatus(accountStatus, '密码需要至少 8 位。'); return; }
    if (!login && passwordInput.value !== confirmInput.value) { setStatus(accountStatus, '两次输入的密码不一致。'); return; }
    if (!login && !consent.checked) { setStatus(accountStatus, '请先同意账号仅用于本次资格登记。'); return; }
    try {
      if (login) {
        const result = await api('/api/auth/login', { method: 'POST', body: { email, password: passwordInput.value } });
        currentUser = result.user;
        csrfToken = result.csrfToken;
        updateAuthLink();
        redirectAfterAuth();
        return;
      }
      await api('/api/auth/register', { method: 'POST', body: { email, password: passwordInput.value } });
      pendingEmail = email;
      pendingEmailText.textContent = email;
      form.hidden = true;
      verifyPanel.hidden = false;
      setStatus(verifyStatus, '验证码已发送，请检查收件箱。', true);
    } catch (error) {
      setStatus(accountStatus, error.message);
    }
  });

  verifyForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    setStatus(verifyStatus, '正在验证……');
    const codeInput = document.querySelector('#verification-code');
    try {
      const result = await api('/api/auth/verify', { method: 'POST', body: { email: pendingEmail, code: codeInput.value.trim() } });
      currentUser = result.user;
      csrfToken = result.csrfToken;
      updateAuthLink();
      verifyForm.hidden = true;
      resendButton.hidden = true;
      successPanel.hidden = false;
      redirectNow.href = nextTarget || '/compare.html';
      let remaining = 5;
      const countdown = document.querySelector('#redirect-countdown');
      countdown.textContent = String(remaining);
      const timer = window.setInterval(() => {
        remaining -= 1;
        countdown.textContent = String(remaining);
        if (remaining <= 0) {
          window.clearInterval(timer);
          redirectAfterAuth();
        }
      }, 1000);
    } catch (error) {
      setStatus(verifyStatus, error.message);
    }
  });

  resendButton?.addEventListener('click', async () => {
    resendButton.disabled = true;
    try {
      const result = await api('/api/auth/resend', { method: 'POST', body: { email: pendingEmail } });
      setStatus(verifyStatus, result.message, true);
    } catch (error) {
      setStatus(verifyStatus, error.message);
    } finally {
      window.setTimeout(() => { resendButton.disabled = false; }, 3000);
    }
  });
};

const setupComparePage = async () => {
  const applyConfig = (config) => {
    document.querySelectorAll('.product-card').forEach((card) => {
      const product = config.products.find((item) => item.slug === card.dataset.productCard);
      const state = card.querySelector('.product-open-state');
      if (product && state) state.textContent = formatProductState(product, config.claim);
    });
  };

  try {
    applyConfig(await loadConfig());
    pollConfig(applyConfig);
  } catch {
    document.querySelectorAll('.product-open-state').forEach((item) => { item.textContent = '状态读取失败'; });
  }
};

const setupClaimPage = async () => {
  const styleSlug = document.body.dataset.style;
  const claimButton = document.querySelector('#claim-submit');
  const claimStatus = document.querySelector('#claim-status');
  const signedIn = document.querySelector('#signed-in');
  const resultPanel = document.querySelector('#claim-result');
  const resultTitle = document.querySelector('#result-title');
  const resultCopy = document.querySelector('#result-copy');
  const externalLink = document.querySelector('#external-link');
  let latestConfig = null;
  let applyConfig = () => {};
  try {
    const config = await loadConfig();
    latestConfig = config;
    const product = config.products.find((item) => item.slug === styleSlug);
    if (product) {
      document.querySelector('#claim-title').innerHTML = `${product.title}<br /><em>资格登记。</em>`;
      document.querySelector('#claim-subtitle').textContent = product.subtitle;
      document.querySelector('#claim-description').textContent = product.description;
      document.querySelector('#claim-mark').textContent = product.mark;
      document.querySelector('#claim-eyebrow').textContent = `QUALIFICATION / ${product.number}`;
    }
    applyConfig = (nextConfig) => {
      latestConfig = nextConfig;
      const nextProduct = nextConfig.products.find((item) => item.slug === styleSlug);
      if (nextProduct) {
        document.querySelector('#claim-description').textContent = `${nextProduct.description} ${formatShippingDate(nextProduct.shippingDate)}`;
      }
      document.querySelector('#claim-window-label').textContent = formatClaimLabel(nextConfig.claim);
      document.querySelector('#claim-window-time').textContent = nextConfig.claim.openAt ? `开放时间：${new Date(nextConfig.claim.openAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })}` : '开放时间将在这里显示';
      if (currentUser) {
        claimButton.disabled = !nextConfig.claim.open || nextProduct?.remaining <= 0;
        claimButton.textContent = nextProduct?.remaining <= 0 ? '已售罄 · 暂不可登记' : nextConfig.claim.open ? '登记这款资格  ↗' : '等待开放  · 暂不可登记';
      }
    };
    applyConfig(config);
    if (currentUser) {
      signedIn.textContent = `当前账号：${currentUser.email}`;
    } else {
      signedIn.textContent = '请先注册或登录账号。';
      claimButton.textContent = '先去注册 / 登录  ↗';
    }
    claimButton.addEventListener('click', async () => {
      if (!currentUser) {
        window.location.href = `/?next=${encodeURIComponent(window.location.pathname)}`;
        return;
      }
      if (!latestConfig?.claim.open) {
        setStatus(claimStatus, `${formatClaimLabel(latestConfig?.claim || { label: '资格申请尚未开放' })}。`);
        return;
      }
      claimButton.disabled = true;
      setStatus(claimStatus, '正在登记资格……');
      try {
        const result = await api('/api/claims', { method: 'POST', body: { styleSlug } });
        resultPanel.hidden = false;
        resultTitle.textContent = result.already ? '你已经登记过这款资格。' : '资格登记成功。';
        resultCopy.textContent = `资格编号：${result.claim.claimNumber}。${result.emailSent ? '确认邮件已经发送到你的邮箱。' : '如果没有收到邮件，也可以在这里查看资格编号。'}`;
        setStatus(claimStatus, '登记已完成。', true);
        if (result.claim.product.externalUrl) { externalLink.href = result.claim.product.externalUrl; externalLink.hidden = false; }
      } catch (error) {
        setStatus(claimStatus, error.message);
        claimButton.disabled = false;
      }
    });
    pollConfig(applyConfig);
  } catch (error) {
    setStatus(claimStatus, '资格状态暂时无法读取，请稍后刷新。');
    claimButton.disabled = true;
  }
};

const main = async () => {
  await restoreSession();
  if (page === 'account') await setupAccountPage();
  if (page === 'compare') await setupComparePage();
  if (page === 'claim') await setupClaimPage();
};

main();
