import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import tls from 'node:tls';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

const currentFile = fileURLToPath(import.meta.url);
const projectRoot = path.dirname(currentFile);
const publicRoot = path.join(projectRoot, 'public');
const dataRoot = path.join(projectRoot, 'data');
const templateRoot = path.join(projectRoot, 'email-templates');
const databaseFile = process.env.PASS_DB_PATH || path.join(dataRoot, 'pass.sqlite');
const host = process.env.HOST || '127.0.0.1';
const port = Number(process.env.PORT || 3100);
const siteUrl = process.env.SITE_URL || 'https://1ogic.cn/';
const emailCodeSecret = process.env.EMAIL_CODE_SECRET || process.env.MESSAGE_IP_SALT || crypto.randomBytes(32).toString('hex');
const smtpUser = process.env.SMTP_USER?.trim() || '';
const smtpPass = process.env.SMTP_PASS || '';
const smtpHost = process.env.SMTP_HOST?.trim() || 'smtp.gmail.com';
const smtpPort = Number(process.env.SMTP_PORT || 465);
const smtpSecure = process.env.SMTP_SECURE !== 'false';
const emailConfigured = Boolean(smtpUser && smtpPass && smtpSecure);
const codeSecretConfigured = Boolean(process.env.EMAIL_CODE_SECRET);
const codeLifetimeMs = 10 * 60 * 1000;
const codeResendCooldownMs = 60 * 1000;
const sessionLifetimeSeconds = 7 * 24 * 60 * 60;
const authRateWindowMs = 60 * 60 * 1000;
const recentAuthRequests = new Map();

const products = {
  'style-1': {
    slug: 'style-1',
    number: '01',
    title: '一体化3D版',
    english: 'INTEGRATED 3D PASS',
    subtitle: '全机身 3D 打印，结构一体成型。',
    description: '14mm 厚度；背板为 3D 打印，无亚克力面板；PETG 材料。新批次取消碳纤维纹理设计。',
    form: '全机身 3D 打印 / 一体化结构',
    scene: '新批次 / 结构统一 / 无亚克力面板',
    mark: 'RI / 3D',
    shippingDate: '2026-09-22'
  },
  'style-2': {
    slug: 'style-2',
    number: '02',
    title: '亚克力版',
    english: 'ACRYLIC PASS',
    subtitle: '3D 打印机身搭配亚克力面板与背板。',
    description: '12mm 厚度；背板、面板均为亚克力；PETG 机身，磨砂质感。机身瑕疵可能略大于全 3D 打印设计。',
    form: '亚克力面板 / 亚克力背板 / PETG 机身',
    scene: '透光 / 磨砂 / 轻薄',
    mark: 'RI / A',
    shippingDate: '2026-09-16'
  }
};

fs.mkdirSync(dataRoot, { recursive: true });
const SQL = await initSqlJs({ locateFile: (file) => path.join(projectRoot, 'node_modules/sql.js/dist', file) });
const rawDatabase = fs.existsSync(databaseFile) ? new SQL.Database(fs.readFileSync(databaseFile)) : new SQL.Database();

function persistRawDatabase() {
  const temporaryFile = `${databaseFile}.tmp`;
  fs.writeFileSync(temporaryFile, Buffer.from(rawDatabase.export()), { mode: 0o600 });
  fs.renameSync(temporaryFile, databaseFile);
  fs.chmodSync(databaseFile, 0o600);
}

class SqliteCompat {
  constructor(database) {
    this.database = database;
    this.transactionDepth = 0;
  }

  exec(sql) {
    this.database.exec(sql);
    persistRawDatabase();
  }

  prepare(sql) {
    return {
      get: (...params) => {
        const statement = this.database.prepare(sql);
        try {
          statement.bind(params);
          return statement.step() ? statement.getAsObject() : undefined;
        } finally {
          statement.free();
        }
      },
      all: (...params) => {
        const statement = this.database.prepare(sql);
        const rows = [];
        try {
          statement.bind(params);
          while (statement.step()) rows.push(statement.getAsObject());
          return rows;
        } finally {
          statement.free();
        }
      },
      run: (...params) => {
        this.database.run(sql, params);
        const lastInsertRowid = this.database.exec('SELECT last_insert_rowid() AS id')[0]?.values[0]?.[0] || 0;
        if (this.transactionDepth === 0) persistRawDatabase();
        return { changes: this.database.getRowsModified(), lastInsertRowid };
      }
    };
  }

  transaction(operation) {
    return (...args) => {
      this.database.run('BEGIN');
      this.transactionDepth += 1;
      try {
        const result = operation(...args);
        this.database.run('COMMIT');
        this.transactionDepth -= 1;
        persistRawDatabase();
        return result;
      } catch (error) {
        this.database.run('ROLLBACK');
        this.transactionDepth -= 1;
        throw error;
      }
    };
  }
}

const db = new SqliteCompat(rawDatabase);
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    email_verified INTEGER NOT NULL DEFAULT 0,
    verification_hash TEXT,
    verification_expires_at INTEGER,
    verification_attempts INTEGER NOT NULL DEFAULT 0,
    verification_sent_at INTEGER,
    created_at TEXT NOT NULL,
    verified_at TEXT
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    csrf_hash TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    style_slug TEXT NOT NULL,
    claim_number TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'qualified',
    created_at TEXT NOT NULL,
    UNIQUE(user_id, style_slug)
  );
  CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
  CREATE INDEX IF NOT EXISTS idx_claims_style_status ON claims(style_slug, status);
`);

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8'
};

function setSecurityHeaders(response) {
  response.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; script-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
  response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
}

function sendJson(response, status, body) {
  setSecurityHeaders(response);
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.writeHead(status);
  response.end(JSON.stringify(body));
}

function normalizeEmail(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function isValidEmail(email) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    request.setEncoding('utf8');
    request.on('data', (chunk) => {
      body += chunk;
      if (Buffer.byteLength(body, 'utf8') > 64 * 1024) {
        reject(Object.assign(new Error('payload too large'), { statusCode: 413 }));
        request.destroy();
      }
    });
    request.on('end', () => {
      try {
        resolve(JSON.parse(body || '{}'));
      } catch {
        reject(Object.assign(new Error('invalid json'), { statusCode: 400 }));
      }
    });
    request.on('error', reject);
  });
}

function clientKey(request) {
  return request.headers['x-real-ip'] || request.socket.remoteAddress || 'unknown';
}

function rateLimited(request, bucket, limit) {
  const key = `${bucket}:${clientKey(request)}`;
  const now = Date.now();
  const previous = (recentAuthRequests.get(key) || []).filter((time) => now - time < authRateWindowMs);
  if (previous.length >= limit) {
    recentAuthRequests.set(key, previous);
    return true;
  }
  previous.push(now);
  recentAuthRequests.set(key, previous);
  return false;
}

function derivePassword(password, salt) {
  return crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  return `scrypt$${salt.toString('hex')}$${derivePassword(password, salt).toString('hex')}`;
}

function verifyPassword(password, encoded) {
  const parts = encoded.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt' || !/^[a-f0-9]+$/i.test(parts[1]) || !/^[a-f0-9]+$/i.test(parts[2])) return false;
  try {
    const expected = Buffer.from(parts[2], 'hex');
    const actual = derivePassword(password, Buffer.from(parts[1], 'hex'));
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function hashOpaque(value) {
  return crypto.createHash('sha256').update(`${emailCodeSecret}:${value}`).digest('hex');
}

function createVerificationCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function parseDateEnv(value) {
  if (!value) return null;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function claimWindow() {
  const openAt = parseDateEnv(process.env.CLAIM_OPEN_AT);
  const closeAt = parseDateEnv(process.env.CLAIM_CLOSE_AT);
  const now = Date.now();
  const open = Boolean(openAt && now >= openAt && (!closeAt || now < closeAt));
  let label = '开放时间待设定';
  if (open) label = '资格申请开放中';
  else if (openAt && now < openAt) label = '尚未开放申请';
  else if (closeAt && now >= closeAt) label = '本轮申请已结束';
  return { open, label, openAt: openAt ? new Date(openAt).toISOString() : null, closeAt: closeAt ? new Date(closeAt).toISOString() : null };
}

function publicProduct(product) {
  const externalKey = product.slug === 'style-1' ? 'STYLE_1_EXTERNAL_URL' : 'STYLE_2_EXTERNAL_URL';
  let externalUrl = null;
  try {
    const candidate = process.env[externalKey] || '';
    const parsed = candidate ? new URL(candidate) : null;
    if (parsed && parsed.protocol === 'https:') externalUrl = parsed.toString();
  } catch {
    externalUrl = null;
  }
  const limit = Number(process.env[`CLAIM_LIMIT_${product.slug === 'style-1' ? 'STYLE_1' : 'STYLE_2'}`] || 20);
  const claimed = claimCount(product.slug);
  return { ...product, externalUrl, limit, claimed, remaining: Math.max(0, limit - claimed) };
}

function productFor(slug) {
  return products[slug] || null;
}

function publicUser(user) {
  return { id: user.id, email: user.email, verified: Boolean(user.email_verified) };
}

function parseCookies(request) {
  const header = request.headers.cookie || '';
  const result = {};
  for (const item of header.split(';')) {
    const [name, ...value] = item.trim().split('=');
    if (name && value.length) result[name] = decodeURIComponent(value.join('='));
  }
  return result;
}

function cookieSecure(request) {
  return process.env.NODE_ENV === 'production' || request.headers['x-forwarded-proto'] === 'https';
}

function setSessionCookie(request, response, token, maxAge) {
  const secure = cookieSecure(request) ? '; Secure' : '';
  response.setHeader('Set-Cookie', `pass_session=${encodeURIComponent(token)}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Lax${secure}`);
}

function getSession(request) {
  const rawToken = parseCookies(request).pass_session;
  if (!rawToken) return null;
  const tokenHash = hashOpaque(rawToken);
  const session = db.prepare(`SELECT sessions.*, users.email, users.email_verified FROM sessions JOIN users ON users.id = sessions.user_id WHERE token_hash = ?`).get(tokenHash);
  if (!session || session.expires_at <= Date.now()) {
    if (session) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    return null;
  }
  return { ...session, tokenHash };
}

function issueSession(request, response, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const csrfToken = crypto.randomBytes(24).toString('base64url');
  const now = new Date().toISOString();
  db.prepare('INSERT INTO sessions (token_hash, user_id, csrf_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)').run(hashOpaque(token), userId, hashOpaque(csrfToken), Date.now() + sessionLifetimeSeconds * 1000, now);
  setSessionCookie(request, response, token, sessionLifetimeSeconds);
  return csrfToken;
}

function refreshCsrf(session) {
  const csrfToken = crypto.randomBytes(24).toString('base64url');
  db.prepare('UPDATE sessions SET csrf_hash = ? WHERE token_hash = ?').run(hashOpaque(csrfToken), session.tokenHash);
  return csrfToken;
}

function requireSession(request, response) {
  const session = getSession(request);
  if (!session) {
    sendJson(response, 401, { error: 'not authenticated' });
    return null;
  }
  return session;
}

function requireCsrf(request, response, session) {
  const token = request.headers['x-csrf-token'];
  if (!token || !crypto.timingSafeEqual(Buffer.from(session.csrf_hash), Buffer.from(hashOpaque(token)))) {
    sendJson(response, 403, { error: 'invalid csrf token' });
    return false;
  }
  return true;
}

function replaceTemplateValues(template, values) {
  return Object.entries(values).reduce((result, [key, value]) => result.replaceAll(`{{${key}}}`, () => String(value)), template);
}

function readSmtpResponse(socket) {
  return new Promise((resolve, reject) => {
    let buffer = '';
    const cleanup = () => {
      socket.off('data', onData);
      socket.off('error', onError);
      socket.off('close', onClose);
    };
    const onData = (chunk) => {
      buffer += chunk.toString('utf8');
      const lines = buffer.split('\r\n');
      buffer = lines.pop() || '';
      const last = lines.findLast((line) => /^\d{3} /.test(line));
      if (!last) return;
      cleanup();
      resolve({ code: Number(last.slice(0, 3)), text: last.slice(4) });
    };
    const onError = (error) => { cleanup(); reject(error); };
    const onClose = () => { cleanup(); reject(new Error('SMTP connection closed')); };
    socket.on('data', onData);
    socket.on('error', onError);
    socket.on('close', onClose);
  });
}

async function smtpCommand(socket, command, expected) {
  socket.write(`${command}\r\n`);
  const response = await readSmtpResponse(socket);
  if (!expected.includes(response.code)) throw new Error(`SMTP ${response.code}: ${response.text}`);
}

function encodeHeader(value) {
  return `=?UTF-8?B?${Buffer.from(value, 'utf8').toString('base64')}?=`;
}

function encodeBody(value) {
  return Buffer.from(value, 'utf8').toString('base64').match(/.{1,76}/g)?.join('\r\n') || '';
}

async function sendEmail({ to, subject, text }) {
  if (!emailConfigured) throw new Error('SMTP is not configured');
  if (!isValidEmail(smtpUser) || !isValidEmail(to) || /[\r\n]/.test(subject)) throw new Error('unsafe email value');
  const socket = tls.connect({ host: smtpHost, port: smtpPort, servername: smtpHost, rejectUnauthorized: true, timeout: 15000 });
  socket.once('timeout', () => socket.destroy(new Error('SMTP timeout')));
  try {
    await new Promise((resolve, reject) => {
      socket.once('secureConnect', resolve);
      socket.once('error', reject);
    });
    const greeting = await readSmtpResponse(socket);
    if (greeting.code !== 220) throw new Error(`SMTP greeting ${greeting.code}`);
    await smtpCommand(socket, 'EHLO 1ogic.cn', [250]);
    await smtpCommand(socket, 'AUTH LOGIN', [334]);
    await smtpCommand(socket, Buffer.from(smtpUser).toString('base64'), [334]);
    await smtpCommand(socket, Buffer.from(smtpPass).toString('base64'), [235]);
    await smtpCommand(socket, `MAIL FROM:<${smtpUser}>`, [250]);
    await smtpCommand(socket, `RCPT TO:<${to}>`, [250, 251]);
    await smtpCommand(socket, 'DATA', [354]);
    const headers = [
      `From: ${encodeHeader('杨易 / 1ogic.cn')} <${smtpUser}>`,
      `To: <${to}>`,
      `Subject: ${encodeHeader(subject)}`,
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=UTF-8',
      'Content-Transfer-Encoding: base64'
    ].join('\r\n');
    socket.write(`${headers}\r\n\r\n${encodeBody(text)}\r\n.\r\n`);
    const accepted = await readSmtpResponse(socket);
    if (accepted.code !== 250) throw new Error(`SMTP message ${accepted.code}: ${accepted.text}`);
    await smtpCommand(socket, 'QUIT', [221, 250]).catch(() => {});
  } finally {
    socket.destroy();
  }
}

async function sendTemplate(templateName, values, recipient, subject) {
  const template = await fsp.readFile(path.join(templateRoot, templateName), 'utf8');
  await sendEmail({ to: recipient, subject, text: replaceTemplateValues(template, values) });
}

async function sendVerification(email, code) {
  await sendTemplate('verification.txt', { code, minutes: 10, siteUrl }, email, '电子通行证邮箱验证码 / 1ogic.cn');
}

function claimCount(slug) {
  return db.prepare(`SELECT COUNT(*) AS count FROM claims WHERE style_slug = ? AND status = 'qualified'`).get(slug).count;
}

function claimView(row) {
  return { id: row.id, styleSlug: row.style_slug, claimNumber: row.claim_number, status: row.status, createdAt: row.created_at, product: publicProduct(products[row.style_slug]) };
}

function authResponse(request, response, userId) {
  const csrfToken = issueSession(request, response, userId);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  return { ok: true, csrfToken, user: publicUser(user) };
}

async function handleRegister(request, response) {
  if (!codeSecretConfigured) { sendJson(response, 503, { error: '账号验证码服务尚未完成安全配置。' }); return; }
  if (rateLimited(request, 'register', 8)) {
    sendJson(response, 429, { error: '请求过于频繁，请稍后再试。' });
    return;
  }
  const payload = await readJson(request);
  const email = normalizeEmail(payload.email);
  const password = typeof payload.password === 'string' ? payload.password : '';
  if (!isValidEmail(email)) { sendJson(response, 400, { error: '请输入有效邮箱。' }); return; }
  if (password.length < 8 || password.length > 128) { sendJson(response, 400, { error: '密码需要 8 至 128 位。' }); return; }
  const existing = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (existing?.email_verified) { sendJson(response, 409, { error: '这个邮箱已经注册，请直接登录。', code: 'account_exists' }); return; }
  if (existing?.verification_sent_at && Date.now() - existing.verification_sent_at < codeResendCooldownMs) {
    sendJson(response, 429, { error: '验证码刚刚已发送，请稍等一分钟再重试。' });
    return;
  }
  const code = createVerificationCode();
  const now = new Date().toISOString();
  const codeSentAt = Date.now();
  const passwordHash = hashPassword(password);
  if (existing) {
    db.prepare('UPDATE users SET password_hash = ?, verification_hash = ?, verification_expires_at = ?, verification_attempts = 0, verification_sent_at = ? WHERE id = ?').run(passwordHash, hashOpaque(code), codeSentAt + codeLifetimeMs, codeSentAt, existing.id);
  } else {
    db.prepare('INSERT INTO users (email, password_hash, verification_hash, verification_expires_at, verification_sent_at, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(email, passwordHash, hashOpaque(code), codeSentAt + codeLifetimeMs, codeSentAt, now);
  }
  try {
    await sendVerification(email, code);
    sendJson(response, 201, { ok: true, message: '验证码已发送到你的邮箱。' });
  } catch (error) {
    console.error('verification email failed:', error.message);
    sendJson(response, 503, { error: '账号已建立待验证记录，但验证码邮件暂时发送失败，请稍后重试。' });
  }
}

async function handleVerify(request, response) {
  if (!codeSecretConfigured) { sendJson(response, 503, { error: '账号验证码服务尚未完成安全配置。' }); return; }
  if (rateLimited(request, 'verify', 20)) { sendJson(response, 429, { error: '请求过于频繁，请稍后再试。' }); return; }
  const payload = await readJson(request);
  const email = normalizeEmail(payload.email);
  const code = typeof payload.code === 'string' ? payload.code.trim() : '';
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || user.email_verified || !user.verification_hash) { sendJson(response, 400, { error: '验证码无效或已过期。' }); return; }
  if (user.verification_expires_at < Date.now() || user.verification_attempts >= 8) { sendJson(response, 400, { error: '验证码无效或已过期，请重新获取。' }); return; }
  if (!/^\d{6}$/.test(code) || !crypto.timingSafeEqual(Buffer.from(user.verification_hash), Buffer.from(hashOpaque(code)))) {
    db.prepare('UPDATE users SET verification_attempts = verification_attempts + 1 WHERE id = ?').run(user.id);
    sendJson(response, 400, { error: '验证码不正确。' });
    return;
  }
  db.prepare('UPDATE users SET email_verified = 1, verification_hash = NULL, verification_expires_at = NULL, verification_attempts = 0, verified_at = ? WHERE id = ?').run(new Date().toISOString(), user.id);
  sendJson(response, 200, authResponse(request, response, user.id));
}

async function handleResend(request, response) {
  if (!codeSecretConfigured) { sendJson(response, 503, { error: '账号验证码服务尚未完成安全配置。' }); return; }
  if (rateLimited(request, 'resend', 8)) { sendJson(response, 429, { error: '请求过于频繁，请稍后再试。' }); return; }
  const payload = await readJson(request);
  const email = normalizeEmail(payload.email);
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || user.email_verified) { sendJson(response, 400, { error: '请先填写未验证的注册邮箱。' }); return; }
  if (user.verification_sent_at && Date.now() - user.verification_sent_at < codeResendCooldownMs) { sendJson(response, 429, { error: '验证码刚刚已发送，请稍等一分钟。' }); return; }
  const code = createVerificationCode();
  const sentAt = Date.now();
  db.prepare('UPDATE users SET verification_hash = ?, verification_expires_at = ?, verification_attempts = 0, verification_sent_at = ? WHERE id = ?').run(hashOpaque(code), sentAt + codeLifetimeMs, sentAt, user.id);
  try {
    await sendVerification(email, code);
    sendJson(response, 200, { ok: true, message: '新的验证码已发送。' });
  } catch (error) {
    console.error('verification resend failed:', error.message);
    sendJson(response, 503, { error: '验证码暂时发送失败，请稍后再试。' });
  }
}

async function handleLogin(request, response) {
  if (rateLimited(request, 'login', 12)) { sendJson(response, 429, { error: '登录尝试过多，请稍后再试。' }); return; }
  const payload = await readJson(request);
  const email = normalizeEmail(payload.email);
  const password = typeof payload.password === 'string' ? payload.password : '';
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !user.email_verified || !verifyPassword(password, user.password_hash)) { sendJson(response, 401, { error: '邮箱或密码不正确。' }); return; }
  sendJson(response, 200, authResponse(request, response, user.id));
}

async function handleClaim(request, response, session) {
  if (!requireCsrf(request, response, session)) return;
  const payload = await readJson(request);
  const product = productFor(payload.styleSlug);
  if (!product) { sendJson(response, 400, { error: '请选择有效款式。' }); return; }
  const window = claimWindow();
  if (!window.open) { sendJson(response, 409, { error: `${window.label}，请留意开放时间。`, code: 'not_open', window }); return; }
  const limit = publicProduct(product).limit;
  const transaction = db.transaction(() => {
    const existing = db.prepare('SELECT * FROM claims WHERE user_id = ? AND style_slug = ?').get(session.user_id, product.slug);
    if (existing) return { kind: 'already', row: existing };
    if (claimCount(product.slug) >= limit) return { kind: 'full' };
    const claimNumber = `EP-${product.number}-${new Date().getFullYear()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const createdAt = new Date().toISOString();
    db.prepare('INSERT INTO claims (user_id, style_slug, claim_number, status, created_at) VALUES (?, ?, ?, ?, ?)').run(session.user_id, product.slug, claimNumber, 'qualified', createdAt);
    const row = db.prepare('SELECT * FROM claims WHERE user_id = ? AND style_slug = ? ORDER BY id DESC').get(session.user_id, product.slug);
    return { kind: 'new', row };
  })();
  if (transaction.kind === 'full') { sendJson(response, 409, { error: '这款的资格名额已经满了。', code: 'full' }); return; }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(session.user_id);
  let emailSent = false;
  if (transaction.kind === 'new' && emailConfigured) {
    try {
      await sendTemplate('claim-qualified.txt', { product: product.title, claimNumber: transaction.row.claim_number, siteUrl }, user.email, `购买资格已登记 / ${product.title}`);
      emailSent = true;
    } catch (error) { console.error('claim result email failed:', error.message); }
  }
  if (transaction.kind === 'already') {
    sendJson(response, 200, { ok: true, already: true, emailSent: false, claim: claimView(transaction.row) });
    return;
  }
  sendJson(response, 201, { ok: true, already: false, emailSent, claim: claimView(transaction.row) });
}

async function serveStatic(request, response, pathname) {
  const requestedPath = pathname === '/' ? '/index.html' : pathname;
  let decodedPath;
  try { decodedPath = decodeURIComponent(requestedPath); } catch { sendJson(response, 400, { error: 'bad path' }); return; }
  const fullPath = path.resolve(publicRoot, `.${decodedPath}`);
  const relative = path.relative(publicRoot, fullPath);
  if (relative.startsWith('..') || path.isAbsolute(relative)) { sendJson(response, 403, { error: 'forbidden' }); return; }
  try {
    const file = await fsp.readFile(fullPath);
    setSecurityHeaders(response);
    response.setHeader('Content-Type', contentTypes[path.extname(fullPath)] || 'application/octet-stream');
    response.writeHead(200);
    response.end(request.method === 'HEAD' ? undefined : file);
  } catch (error) {
    sendJson(response, error.code === 'ENOENT' ? 404 : 500, { error: error.code === 'ENOENT' ? 'not found' : 'server error' });
  }
}

const server = http.createServer(async (request, response) => {
  const requestUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
  try {
    if (request.method === 'GET' && requestUrl.pathname === '/health') {
      sendJson(response, 200, { ok: true, database: true, emailConfigured, codeSecretConfigured, claim: claimWindow() });
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/api/config') {
      const session = getSession(request);
      sendJson(response, 200, { products: Object.values(products).map(publicProduct), claim: claimWindow(), authenticated: Boolean(session), user: session ? { id: session.user_id, email: session.email } : null });
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/auth/register') { await handleRegister(request, response); return; }
    if (request.method === 'POST' && requestUrl.pathname === '/api/auth/verify') { await handleVerify(request, response); return; }
    if (request.method === 'POST' && requestUrl.pathname === '/api/auth/resend') { await handleResend(request, response); return; }
    if (request.method === 'POST' && requestUrl.pathname === '/api/auth/login') { await handleLogin(request, response); return; }
    if (request.method === 'GET' && requestUrl.pathname === '/api/auth/session') {
      const session = getSession(request);
      if (!session) { sendJson(response, 200, { authenticated: false }); return; }
      sendJson(response, 200, { authenticated: true, csrfToken: refreshCsrf(session), user: { id: session.user_id, email: session.email } });
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/auth/logout') {
      const session = getSession(request);
      if (session) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(session.tokenHash);
      setSessionCookie(request, response, '', 0);
      sendJson(response, 200, { ok: true });
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/api/claims') {
      const session = requireSession(request, response);
      if (!session) return;
      const rows = db.prepare('SELECT * FROM claims WHERE user_id = ? ORDER BY created_at DESC').all(session.user_id);
      sendJson(response, 200, rows.map(claimView));
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/claims') {
      const session = requireSession(request, response);
      if (!session) return;
      await handleClaim(request, response, session);
      return;
    }
    if (request.method === 'GET' || request.method === 'HEAD') { await serveStatic(request, response, requestUrl.pathname); return; }
    sendJson(response, 405, { error: 'method not allowed' });
  } catch (error) {
    console.error('request failed:', error);
    sendJson(response, error.statusCode || 500, { error: error.statusCode ? error.message : 'server error' });
  }
});

server.listen(port, host, () => {
  console.log(`pass box listening on http://${host}:${port}`);
});
