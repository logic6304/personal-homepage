# pass.1ogic.cn 资格系统

这是明日方舟电子通行证的真实账号和购买资格服务。它与 `message-box` 匿名信箱分开运行，但共用同一个 Gmail SMTP 账号；两边的邮件模板不同。

## 功能

- 邮箱注册与 6 位验证码确认
- `scrypt` 单向密码哈希，不保存明文密码
- HttpOnly 登录会话和 CSRF 校验
- SQLite 私有数据库
- 两款资格预留：一体化3D版 `style-1`、亚克力版 `style-2`
- 横向比较页 `/compare.html`
- 独立资格页 `/claim-style-1.html`、`/claim-style-2.html`
- 用 `CLAIM_OPEN_AT` 控制开放时间，用 `CLAIM_LIMIT_STYLE_1/2` 控制名额
- 同一账号对同一款只能登记一次，名额在数据库事务中扣减
- 不收款；以后可以通过 `STYLE_1_EXTERNAL_URL`、`STYLE_2_EXTERNAL_URL` 配置外部后续链接

## 本地运行

需要 Node.js 20+。数据库使用纯 WebAssembly SQLite，不需要 C++ 编译器：

```bash
npm install
SMTP_USER='' SMTP_PASS='' npm start
```

默认监听 `127.0.0.1:3100`。前端页面：`http://127.0.0.1:3100/`。

## VPS 部署

建议目录：`/opt/pass-box`，systemd 服务名：`pass-box`，Nginx 域名：`pass.1ogic.cn`。

Ubuntu 首次安装常用工具：

```bash
apt-get update
apt-get install -y unzip openssl
```

解压部署包后：

```bash
cd /opt/pass-box
npm install --omit=dev
mkdir -p /opt/pass-box/data
```

创建 `/etc/pass-box.env`。真实 Gmail 应用专用密码只写这里，不要发到聊天、GitHub 或压缩包：

```ini
NODE_ENV=production
HOST=127.0.0.1
PORT=3100
SITE_URL=https://1ogic.cn/
EMAIL_CODE_SECRET=请在VPS上随机生成一串新的长随机字符串

SMTP_HOST=smtpdm.aliyun.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=你的阿里云发信地址
SMTP_PASS=阿里云SMTP专用密码

# 例：北京时间 2026-09-20 20:00:00
CLAIM_OPEN_AT=2026-09-20T20:00:00+08:00
# 不填写表示不自动结束
CLAIM_CLOSE_AT=
CLAIM_LIMIT_STYLE_1=10
CLAIM_LIMIT_STYLE_2=10

# 暂时留空；以后放外部咸鱼等 HTTPS 链接
STYLE_1_EXTERNAL_URL=
STYLE_2_EXTERNAL_URL=
```

`EMAIL_CODE_SECRET` 不能留空。可在 VPS 生成后复制到环境文件，不要把输出发给 GPT：

```bash
openssl rand -hex 32
chmod 600 /etc/pass-box.env
```

systemd 文件 `/etc/systemd/system/pass-box.service` 可以直接参考包内的 `pass-box.service.example`：

```ini
[Unit]
Description=1ogic e-pass qualification service
After=network.target

[Service]
Type=simple
User=passbox
Group=passbox
WorkingDirectory=/opt/pass-box
EnvironmentFile=/etc/pass-box.env
ExecStart=/usr/bin/node /opt/pass-box/server.js
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/pass-box/data

[Install]
WantedBy=multi-user.target
```

初始化用户和服务：

```bash
id passbox >/dev/null 2>&1 || useradd --system --home /opt/pass-box --shell /usr/sbin/nologin passbox
chown -R passbox:passbox /opt/pass-box
systemctl daemon-reload
systemctl enable --now pass-box
systemctl status pass-box --no-pager
curl -sS http://127.0.0.1:3100/health
```

健康检查应包含：`"database":true`、`"emailConfigured":true` 和资格开放状态。

## Nginx

为 `pass.1ogic.cn` 添加阿里云 DNS：

```text
类型：A
主机记录：pass
记录值：149.104.12.157
```

包内的 `nginx-pass-box.example.conf` 可作为 Nginx 配置参考。Nginx 代理到 `127.0.0.1:3100`，然后用 Certbot 为 `pass.1ogic.cn` 配置 HTTPS。外部的 `1ogic.cn` 主站仍然继续指向 GitHub Pages。

## 邮件模板

- `email-templates/verification.txt`：注册验证码
- `email-templates/claim-qualified.txt`：资格登记成功
- `email-templates/claim-already.txt`：重复登记提示备用模板

修改模板后重启 `pass-box`。当前验证码会在 10 分钟后过期，错误尝试 8 次后失效。

## 重要边界

当前系统只提供资格登记，不付款、不扣库存商品、不自动跳转到外部平台。外部链接只有在对应环境变量填写 HTTPS 地址后，资格成功页面才会显示。

数据库文件是 `/opt/pass-box/data/pass.sqlite`，不要上传 GitHub，也不要把它发给聊天模型。上线前建议定期备份这个文件，但备份也要放在私有位置。
